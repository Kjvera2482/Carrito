/* Esta lista podría ser reemplazada por la respuesta de un backend */
const bicicletas = [
  {
    id:1,
    nombre: "Guantes Arquero",
    precio: 21,
  },
  {
    id:2,
    nombre: "Rodillera",
    precio: 25,
  },
  {
    id:3,
    nombre: "Mini arcos training",
    precio: 35,
  },
  {
    id:4,
    nombre: "Balón tira táctica",
    precio: 40,
  },
  {
    id:5,
    nombre: "Kit arcos conos",
    precio: 45,
  },
  {
    id:6,
    nombre: "Balón cinta táctica",
    precio: 55,
  }
]